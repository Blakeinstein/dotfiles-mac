sketchybar --set $NAME label="$(date '+%a, %b %d')"
