sketchybar --set $NAME label="$(date '+%H:%M')"
