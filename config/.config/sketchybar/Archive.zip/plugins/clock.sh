#!/usr/bin/env zsh

sketchybar --set $NAME label="$(date '+%a %b %-d %-H:%M')"
